
#include "blue_data.h"
#include "main.h"

#ifdef __cplusplus
extern "C" {
#endif

void tcp_main(mpu_data *global_mpu_data);
#ifdef __cplusplus
}
#endif